<div class="list-group list-group-flush">
    <a href="<?php echo e(url('home')); ?>" class="list-group-item list-group-item-action <?php echo e(($active ?? '') === 'home' ? 'selected' : ''); ?>">Товары</a>
    <a href="<?php echo e(url('orders')); ?>" class="list-group-item list-group-item-action <?php echo e(($active ?? '') === 'orders' ? 'selected' : ''); ?>">Заказы</a>
    <a href="<?php echo e(url('brands')); ?>" class="list-group-item list-group-item-action <?php echo e(($active ?? '') === 'brands' ? 'selected' : ''); ?>">Бренды</a>
    <a href="<?php echo e(route('broadcasts')); ?>" class="list-group-item list-group-item-action <?php echo e(($active ?? '') === 'broadcasts' ? 'selected' : ''); ?>">Рассылки</a>
    <a href="<?php echo e(route('message-templates.index')); ?>" class="list-group-item list-group-item-action <?php echo e(($active ?? '') === 'templates' ? 'selected' : ''); ?>">Шаблоны сообщений</a>
    <a href="<?php echo e(route('kaspi-status.index')); ?>" class="list-group-item list-group-item-action <?php echo e(($active ?? '') === 'kaspi-status' ? 'selected' : ''); ?>">Статус Kaspi</a>
</div>
<?php /**PATH C:\OSPanel\home\atir_shop\resources\views/partials/admin-sidebar.blade.php ENDPATH**/ ?>