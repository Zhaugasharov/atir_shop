

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="list-group list-group-flush">
                                <a href="<?php echo e(url('home')); ?>" class="list-group-item list-group-item-action">Товары</a>
                                <a href="<?php echo e(url('orders')); ?>" class="list-group-item list-group-item-action selected">Заказы</a>
                                <a href="<?php echo e(url('brands')); ?>" class="list-group-item list-group-item-action">Бренды</a>
                            </div>
                        </div>
                        <div class="col-md-9">
                            <h4>Заказы</h4>
                            <hr class="my-4" style="border-top:1px solid #e0e0e0;">
                            <form method="GET" action="<?php echo e(route('orders')); ?>" class="mb-4">
                                <div class="form-row">
                                    <div class="col-md-6">
                                        <input type="text"
                                               name="name"
                                               class="form-control"
                                               placeholder="Номер заказа или номер телефона"
                                               value="<?php echo e(request('name')); ?>">
                                    </div>
                                    <div class="col-md-3">
                                        <select name="status" class="form-control">
                                            <option value="">Все</option>
                                            <option value="1" <?php echo e(request('status') == '1' ? 'selected' : ''); ?>>Новый</option>
                                            <option value="2" <?php echo e(request('status') == '2' ? 'selected' : ''); ?>>Выбран</option>
                                        </select>
                                    </div>

                                    <div class="col-md-2">
                                        <button class="btn btn-dark btn-block">Найти</button>
                                    </div>
                                </div>
                            </form>

                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Номер заказа</th>
                                        <th>Номер клиента</th>
                                        <th>Статус</th>
                                        <th>Тип 1</th>
                                        <th>Тип 2</th>
                                        <th>Тип 3</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td ><?php echo e($order->order_id); ?></td>
                                            <td><?php echo e($order->phone); ?></td>
                                            <td><?php echo e($order->getStatus()); ?></td>
                                            <td width="250px">
                                                <?php if(!empty($order->product1->name)): ?>
                                                    <p><?php echo e($order->product1->name); ?></p>
                                                    <img width="100%" src="<?php echo e($order->product1->image_url); ?>" />
                                                <?php endif; ?>
                                            </td>
                                            <td width="250px">
                                                <?php if(!empty($order->product2->name)): ?>
                                                    <p><?php echo e($order->product2->name); ?></p>
                                                    <img width="100%" src="<?php echo e($order->product2->image_url); ?>" />
                                                <?php endif; ?>
                                            </td>
                                            <td width="250px">
                                                <?php if(!empty($order->product3->name)): ?>
                                                    <p><?php echo e($order->product3->name); ?></p>
                                                    <img width="100%" src="<?php echo e($order->product3->image_url); ?>" />
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <?php if($orders->hasPages()): ?>
                                <div class="mt-4">
                                    <?php echo e($orders->withQueryString()->links('pagination::bootstrap-4')); ?>

                                </div>
                            <?php endif; ?>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\home\atir_shop\resources\views/orders.blade.php ENDPATH**/ ?>