<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div id="product_<?php echo e($product->id); ?>" product-id="<?php echo e($product->id); ?>" class="col-md-6 mb-3 card-item">
        <div class="product-card">
            <div class="product-card__image">
                <img id="product_img_<?php echo e($product->id); ?>" src="<?php echo e($product->image_url); ?>" alt="<?php echo e($product->name); ?>">
                <?php if($product->is_new): ?>
                    <span class="product-card__new-flag"><?php echo e(__('messages.novelties')); ?></span>
                <?php endif; ?>
                <span class="product-card__badge"><?php echo e($product->article ?? ''); ?></span>
                <?php if($product->gender): ?>
                    <span class="product-card__type"><?php echo e(__('messages.'.$product->gender)); ?></span>
                <?php endif; ?>
            </div>
            <div class="product-card__info">
                <h5 id="product_title_<?php echo e($product->id); ?>" class="product-card__name"><?php echo e($product->name); ?></h5>
                <?php if($product->brand): ?>
                    <p class="product-card__brand"><?php echo e($product->brand->name); ?></p>
                <?php endif; ?>
                <?php if($product->keywords->count() > 0): ?>
                    <p class="product-card__keywords">
                        <?php echo e($product->keywords->pluck('name')->implode(', ')); ?>

                    </p>
                <?php endif; ?>
                <div class="product-card__tags">
                    <?php $__currentLoopData = $product->keywords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyword): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="product-card__tag"><?php echo e($keyword->name); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="product-card__actions">
                    <?php if(empty($homePage)): ?>
                        <button type="button" product-id="<?php echo e($product->id); ?>" class="product-add float-end btn-fragrancia-select">
                            <i class="bi bi-plus-circle"></i> <span><?php echo e(__('messages.select')); ?></span>
                        </button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\OSPanel\home\atir_shop\resources\views/partials/product-cards.blade.php ENDPATH**/ ?>