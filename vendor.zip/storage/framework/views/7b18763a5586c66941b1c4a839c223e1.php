

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3">
                            <?php echo $__env->make('partials.admin-sidebar', ['active' => 'brands'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="col-md-9">
                            <h4>Бренды</h4>
                            <hr class="my-4" style="border-top:1px solid #e0e0e0;">

                            <button class="btn btn-primary mb-3" data-toggle="modal" data-target="#brandModal" id="addBrandBtn">
                                Добавить бренд
                            </button>

                            <div class="modal fade" id="brandModal" tabindex="-1" role="dialog">
                                <div class="modal-dialog" role="document">
                                    <form id="brandForm" action="<?php echo e(route('saveBrand')); ?>" method="POST" class="modal-content">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="brand_id" id="brandId">

                                        <div class="modal-header">
                                            <h5 class="modal-title" id="brandModalTitle">Добавить бренд</h5>
                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        </div>

                                        <div class="modal-body">
                                            <div class="form-group">
                                                <label>Название бренда</label>
                                                <input type="text" name="name" class="form-control" required id="brandName" value="<?php echo e(old('name')); ?>">
                                            </div>
                                        </div>

                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Отмена</button>
                                            <button type="submit" class="btn btn-success">Сохранить</button>
                                        </div>
                                    </form>
                                </div>
                            </div>

                            <form method="GET" action="<?php echo e(route('brands')); ?>" class="mb-4">
                                <div class="form-row">
                                    <div class="col-md-8">
                                        <input type="text" name="name" class="form-control" placeholder="Поиск по названию" value="<?php echo e(request('name')); ?>">
                                    </div>
                                    <div class="col-md-4">
                                        <button class="btn btn-dark btn-block">Найти</button>
                                    </div>
                                </div>
                            </form>

                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Название</th>
                                        <th>Кол-во товаров</th>
                                        <th>Действия</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($brand->id); ?></td>
                                            <td><?php echo e($brand->name); ?></td>
                                            <td><?php echo e($brand->products_count); ?></td>
                                            <td>
                                                <button class="btn btn-sm btn-outline-primary edit-brand-btn"
                                                        data-toggle="modal"
                                                        data-target="#brandModal"
                                                        data-id="<?php echo e($brand->id); ?>"
                                                        data-name="<?php echo e($brand->name); ?>">
                                                    Редактировать
                                                </button>
                                                <form method="POST" action="<?php echo e(route('deleteBrand', $brand->id)); ?>" class="d-inline"
                                                      onsubmit="return confirm('Удалить бренд?');">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-sm btn-outline-danger">Удалить</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                            <?php if($brands->hasPages()): ?>
                                <div class="mt-4">
                                    <?php echo e($brands->withQueryString()->links('pagination::bootstrap-4')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#addBrandBtn').click(function() {
        $('#brandId').val('');
        $('#brandName').val('');
        $('#brandModalTitle').text('Добавить бренд');
    });

    $(document).on('click', '.edit-brand-btn', function() {
        $('#brandId').val($(this).data('id'));
        $('#brandName').val($(this).data('name'));
        $('#brandModalTitle').text('Редактировать бренд');
    });

    $('#brandModal').on('hidden.bs.modal', function() {
        $('#brandId').val('');
        $('#brandName').val('');
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\home\atir_shop\resources\views/brands.blade.php ENDPATH**/ ?>