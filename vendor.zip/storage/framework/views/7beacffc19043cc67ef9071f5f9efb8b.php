

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3">
                            <?php echo $__env->make('partials.admin-sidebar', ['active' => 'broadcasts'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="col-md-9">
                            <h4>Рассылки</h4>
                            <hr class="my-4" style="border-top:1px solid #e0e0e0;">
                            <form method="GET" action="<?php echo e(route('broadcasts')); ?>" class="mb-4">
                                <div class="form-row">
                                    <div class="col-md-6">
                                        <input type="text"
                                               name="search"
                                               class="form-control"
                                               placeholder="Номер заказа, телефон или текст сообщения"
                                               value="<?php echo e(request('search')); ?>">
                                    </div>
                                    <div class="col-md-3">
                                        <select name="delivery_status" class="form-control">
                                            <option value="">Все статусы</option>
                                            <option value="sent" <?php echo e(request('delivery_status') == 'sent' ? 'selected' : ''); ?>>Отправлено</option>
                                            <option value="delivered" <?php echo e(request('delivery_status') == 'delivered' ? 'selected' : ''); ?>>Доставлено</option>
                                            <option value="failed" <?php echo e(request('delivery_status') == 'failed' ? 'selected' : ''); ?>>Не доставлено</option>
                                        </select>
                                    </div>
                                    <div class="col-md-2">
                                        <button class="btn btn-dark btn-block">Найти</button>
                                    </div>
                                </div>
                            </form>

                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Номер заказа</th>
                                        <th>Телефон</th>
                                        <th>Сообщение</th>
                                        <th>Статус</th>
                                        <th>Дата</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $broadcast_messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($bm->order ? $bm->order->order_id : '-'); ?></td>
                                            <td><?php echo e($bm->phone); ?></td>
                                            <td style="max-width: 300px;"><?php echo e(Str::limit($bm->message, 80)); ?></td>
                                            <td><?php echo e($bm->getStatusLabel()); ?></td>
                                            <td><?php echo e($bm->created_at->format('d.m.Y H:i')); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <?php if($broadcast_messages->isEmpty()): ?>
                                <p class="text-muted">Нет рассылок</p>
                            <?php endif; ?>
                            <?php if($broadcast_messages->hasPages()): ?>
                                <div class="mt-4">
                                    <?php echo e($broadcast_messages->withQueryString()->links('pagination::bootstrap-4')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\home\atir_shop\resources\views/broadcasts/index.blade.php ENDPATH**/ ?>